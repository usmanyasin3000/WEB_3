import { Link, useLocation } from "react-router-dom";
import React, { useEffect, useRef, useState } from "react";
import {
  prepareWriteContract,
  waitForTransaction,
  writeContract,
} from "@wagmi/core";
import { ContractAbi, ContractAddress } from "../../utils/Contract";
import toast from "react-hot-toast";
import { useAccount } from "wagmi";
import { useNavigate } from "react-router-dom";
import bgImgae from "../../assets/bgImgae.jpg";
import axios from "axios";
const ipfsClient = require("ipfs-http-client");
//const ipfs = ipfsClient.create({ host: 'ipfs.infura.io', port: 5001, protocol: 'https' });

const auth =
  "Basic " +
  Buffer.from(
    `2QHErwIJpoK3MpmsHbjR3gmFGZ8:68be7ad9dda60bf7fd303dbfb9c3dfbf`
  ).toString("base64");
const ipfs = ipfsClient.create({
  host: "ipfs.infura.io",
  port: 5001,
  protocol: "https",
  apiPath: "/api/v0",
  headers: { authorization: auth },
});

function AddStudent() {
  const { address } = useAccount();
  const [spinner, setspinner] = useState(false);
  const [getValues, setgetValues] = useState([]);
  const [imagesUpload, setimagesUpload] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const inputRef = useRef();

  const navigate = useNavigate();
  const handleChange = (e) => {
    const { name, value } = e.target;
    setgetValues({ ...getValues, [name]: value });
  };

  const handleClick = () => {
    // 👇️ open file input box on click of other element
    inputRef.current.click();
  };
  const imagepreview = (e) => {
    var file = e.target.files[0];
    const MAX_FILE_SIZE = 500; // 5MB
    const fileSizeKiloBytes = file.size / 1024;
    // console.log(fileSizeKiloBytes);
    if (fileSizeKiloBytes > MAX_FILE_SIZE) {
    } else {
      setImageUrl(URL.createObjectURL(e.target.files[0]));
      setimagesUpload(file);
    }
  };

  const addStudent = async () => {
    try {
      setspinner(true);
      let jsonUsrl = "";
      if (imagesUpload !== "") {
        const fileAdded = await ipfs.add(imagesUpload);
        if (!fileAdded) {
          console.error("Something went wrong when updloading the file");
          setspinner(false);
          return;
        }
        const metadata = {
          title: "Asset Metadata",
          type: "object",
          properties: {
            image: fileAdded.path,
          },
        };
        const metadataAdded = await ipfs.add(JSON.stringify(metadata));
        if (!metadataAdded) {
          console.error("Something went wrong when updloading the file");
          setspinner(false);
          return;
        }
        let API_url = `https://skywalker.infura-ipfs.io/ipfs/${metadataAdded.path}`;
        let Response = await axios.get(API_url);
        jsonUsrl = `https://skywalker.infura-ipfs.io/ipfs/${Response.data.properties.image}`;
      }
      console.log("jsonUsrl", jsonUsrl);

      setspinner(true);
      const { request } = await prepareWriteContract({
        address: ContractAddress,
        abi: ContractAbi,
        functionName: "addStudent",
        args: [
          getValues.name,
          getValues.rollnumber,
          getValues.location,
          getValues?.email,
          getValues?.phonenumber,
          getValues?.country,
          getValues.university,
          [getValues.Computer],
          getValues?.bio,
          jsonUsrl,
        ],
        account: address,
      });
      const { hash } = await writeContract(request);
      const data = await waitForTransaction({
        hash,
      });
      setTimeout(() => {
        setspinner(false);
        toast.success("You Buy this Product successfully");
        navigate("/");
      }, 3000);
    } catch (error) {
      console.log(error);
      setspinner(false);
    }
  };

  // console.log("getValues", getValues);
  return (
    <div className="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto min-h-[550px]">
      {/* Page header */}
      <div className="flex flex-row justify-between items-center mb-8">
        {/* Left: Title */}
        <div className="mb-4 sm:mb-0">
          <h1 className="text-2xl md:text-3xl text-slate-800 font-bold">
            Add Student✨
          </h1>
        </div>
        <div className="grid grid-flow-col sm:auto-cols-max justify-start sm:justify-end gap-2">
          <button
            className="bg-primarycl text-white px-4 py-2 rounded-md"
            onClick={addStudent}
          >
            {spinner ? "Loading..." : "Save"}
          </button>
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "center" }}>
        <div className="lg:w-1/5 w-full  ">
          <div className="flex flex-col  mt-3">
            <div className="flex" onClick={() => handleClick()}>
              <input
                style={{ display: "none" }}
                ref={inputRef}
                type="file"
                onChange={(e) => {
                  imagepreview(e);
                }}
              />
              <div className="">
                <img
                  src={imageUrl || bgImgae}
                  alt=""
                  style={{
                    borderRadius: "50%",
                    width: "210px",
                    height: "200px",
                    border: "3px solid #000",
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-5">
        <div>
          <label className="block text-sm font-medium mb-1" htmlFor="name">
            Full Name
          </label>
          <input
            className="form-input w-full h-10 bg-white text-black"
            type="text"
            name="name"
            onChange={(e) => handleChange(e)}
            style={{ color: "black" }}
          />
        </div>
        <div>
          <label
            className="block text-sm font-medium mb-1"
            htmlFor="rollnumber"
          >
            Roll Number
          </label>
          <input
            className="form-input w-full h-10 bg-white  text-black"
            type="text"
            name="rollnumber"
            onChange={(e) => handleChange(e)}
            style={{ color: "black" }}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" htmlFor="location">
            Location
          </label>
          <input
            className="form-input w-full h-10 bg-white text-slate-800"
            type="text"
            name="location"
            onChange={(e) => handleChange(e)}
            style={{ color: "black" }}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" htmlFor="email">
            Email Address
          </label>
          <input
            className="form-input w-full h-10 bg-white text-slate-800"
            type="email"
            name="email"
            onChange={(e) => handleChange(e)}
            style={{ color: "black" }}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" htmlFor="phnno">
            Phone Number
          </label>
          <input
            className="form-input w-full h-10 bg-white text-slate-800"
            type="number"
            name="phonenumber"
            onChange={(e) => handleChange(e)}
            style={{ color: "black" }}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" htmlFor="country">
            Country
          </label>
          <input
            className="form-input w-full h-10 bg-white text-slate-800"
            type="text"
            name="country"
            onChange={(e) => handleChange(e)}
            style={{ color: "black" }}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" htmlFor="uniname">
            University Name
          </label>
          <input
            className="form-input w-full h-10 bg-white text-slate-800"
            type="text"
            name="university"
            onChange={(e) => handleChange(e)}
            style={{ color: "black" }}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" htmlFor="subjects">
            Subjects
          </label>
          <div className="flex gap-2">
            <input
              className=""
              type="checkbox"
              name="Computer"
              value="Computer Science"
              onChange={(e) => handleChange(e)}
              style={{ color: "black" }}
            />
            <label htmlFor="">Computer Science</label>
          </div>
          <div className="flex gap-2">
            <input
              className=""
              type="checkbox"
              name="Biology"
              value="Biology"
              onChange={(e) => handleChange(e)}
            />
            <label htmlFor="">Biology</label>
          </div>
          <div className="flex gap-2">
            <input
              className=""
              type="checkbox"
              name="Physics"
              value="Physics"
              onChange={(e) => handleChange(e)}
            />
            <label htmlFor="">Physics</label>
          </div>
          <div className="flex gap-2">
            <input
              className=""
              type="checkbox"
              name="Chemistry"
              value="Chemistry"
              onChange={(e) => handleChange(e)}
            />
            <label htmlFor="">Chemistry</label>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" htmlFor="Bio">
            Bio
          </label>
          <textarea
            className="form-input w-full bg-white text-slate-800"
            cols={10}
            rows={5}
            name="bio"
            onChange={(e) => handleChange(e)}
            style={{ color: "black" }}
          />
        </div>
      </div>
    </div>
  );
}

export default AddStudent;
