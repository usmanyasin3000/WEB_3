/* eslint-disable react/jsx-no-undef */
import herobg from "../../assets/herobg.jpg";
import { Link } from "react-router-dom";
import Image01 from "../../assets/user-64-01.jpg";
import Image02 from "../../assets/user-64-02.jpg";
import Image03 from "../../assets/user-64-03.jpg";
import Image04 from "../../assets/user-64-04.jpg";
import Image05 from "../../assets/user-64-05.jpg";
import Image06 from "../../assets/user-64-06.jpg";
import UsersTilesCard from "./UserTilesCard";
import Web3 from "web3";
import { useEffect, useState } from "react";
import { ContractAbi, ContractAddress } from "../../utils/Contract";

// import AppImage09 from '../../assets/coffee (5).jpg';
const items = [
  {
    id: 0,
    name: "Dominik McNeail",
    image: Image01,
    link: "#0",
    rollnumber: "101",
    location: "Lahore",
    country: "Pakistan",
  },
  {
    id: 1,
    name: "Ivan Mesaros",
    image: Image02,
    link: "#0",
    rollnumber: "102",
    location: "Islamabad",
    country: "Pakistan",
  },
  {
    id: 2,
    name: "Tisha Yanchev",
    image: Image03,
    link: "#0",
    rollnumber: "103",
    location: "Multan",
    country: "Pakistan",
  },
  {
    id: 3,
    name: "Sergio Gonnelli",
    image: Image04,
    link: "#0",
    rollnumber: "104",
    location: "Karachi",
    country: "Pakistan",
  },
  {
    id: 4,
    name: "Jerzy Wierzy",
    image: Image05,
    link: "#0",
    rollnumber: "105",
    location: "Lahore",
    country: "Pakistan",
  },
  {
    id: 5,
    name: "Mirko Grubisic",
    image: Image06,
    link: "#0",
    rollnumber: "106",
    location: "Lahore",
    country: "Pakistan",
  },
];
export default function Homepage() {
  const webSupply = new Web3("wss://bsc-testnet-rpc.publicnode.com");
  const [userData, setuserData] = useState([]);
  const getMedicine = async () => {
    try {
      let newArray = [];
      let ContractOf = new webSupply.eth.Contract(ContractAbi, ContractAddress);
      let StudentCount = await ContractOf.methods.getTotalStudents().call();
      for (let i = 0; i < StudentCount; i++) {
        let studentAddresses = await ContractOf.methods.studentAddresses(i).call();
        console.log("studentAddresses",studentAddresses);
        let student = await ContractOf.methods.getStudent(studentAddresses).call();
        newArray = [
          ...newArray,
          {
            id:i,
            name: student?.fullName,
            location: student?.location,
            phoneNumber: student.phoneNumber,
            universityName: student?.universityName,
            rollNumber: student.rollNumber,
            image: student?.profileImageHash,
            subjects:student?.subjects,
            bio:student.bio,
            country:student?.country,
            email:student?.emailAddress

          },
        ];
      }
      console.log("StudentCount", newArray);
      setuserData(newArray);
      // setFilteredData(newArray)
    } catch (error) {
      console.log(error);
    }
  };
   useEffect(() => {
    getMedicine();
  }, []);

  return (
    <div>
      <div
        className="relative min-h-[550px] flex flex-col justify-center items-start z-0"
        style={{
          backgroundImage: `url(${herobg})`,
          backgroundRepeat: "no-repeat",
          // backgroundPosition:'cover',
          backgroundSize: "100% 100%",
        }}
      >
        <div className="absolute inset-0 bg-gray-900 opacity-75 z-10"></div>
        <div className="px-4 md:px-10 lg:px-20 py-10 max-w-screen-lg z-20">
          <div className="flex flex-col justify-center items-start gap-3">
            <h1 className="text-xl md:text-4xl font-bold text-white uppercase">
              <span className="text-primarycl capitalize">
                Welcome to Our Student Management System
              </span>
            </h1>
            <p className="text-lg font-normal text-white">
              Empower your institution with our comprehensive platform.
            </p>
            {/* <Link to="/">
                            <button className="bg-primarycl text-white text-sm font-medium text-center px-6 py-3 rounded-md">
                                Connect Wallet
                            </button>
                        </Link> */}
          </div>
        </div>
      </div>
      <div className="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        {/* Page header */}
        <div className="sm:flex sm:justify-between sm:items-center mb-8">
          {/* Left: Title */}
          <div className="mb-4 sm:mb-0">
            <h1 className="text-2xl md:text-3xl text-slate-800 font-bold">
              Student Detail ✨
            </h1>
          </div>

          <div className="grid grid-flow-col sm:auto-cols-max justify-start sm:justify-end gap-2">
            <Link to="/addstudent">
              <button className="btn bg-primarycl text-white">
                <svg
                  className="w-4 h-4 fill-current opacity-50 shrink-0"
                  viewBox="0 0 16 16"
                >
                  <path d="M15 7H9V1c0-.6-.4-1-1-1S7 .4 7 1v6H1c-.6 0-1 .4-1 1s.4 1 1 1h6v6c0 .6.4 1 1 1s1-.4 1-1V9h6c.6 0 1-.4 1-1s-.4-1-1-1z" />
                </svg>
                <span className="hidden sm:block ml-2">Add Member</span>
              </button>
            </Link>
          </div>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-12 gap-6">
          {userData.map((item) => {
            return (
              <UsersTilesCard
                key={item.id}
                id={item.id}
                name={item.name}
                image={item.image}
                link={item.link}
                rollnumber={item.rollNumber}
                location={item.location}
                country={item.country}
                items={item}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
