/* eslint-disable react/prop-types */
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

function UsersTilesCard(props) {
  const navigate = useNavigate();
  return (
    <div className="col-span-full sm:col-span-6 xl:col-span-4 bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
      <div className="flex flex-col h-full">
        {/* Card top */}
        <div className="grow p-5">
          <div className="flex justify-between items-start">
            <header>
              <div className="flex mb-2">
                <Link
                  className="relative inline-flex items-start mr-5"
                  to={props.link}
                >

                  <img
                    className="rounded-full"
                    src={props.image}
                    width="64"
                    height="64"
                    alt={props.name}
                  />
                </Link>
                <div className="mt-1 pr-1">
                  <Link
                    className="inline-flex text-slate-800 dark:text-slate-100 hover:text-slate-900 dark:hover:text-white"
                    to={props.link}
                  >
                    <h2 className="text-xl leading-snug justify-center font-semibold">
                      {props.name}
                    </h2>
                  </Link>
                  <div className="flex items-center">
                    <span className="text-sm font-medium text-slate-100 -mt-0.5 mr-1">
                      -&gt;
                    </span>{" "}
                    <span className="text-slate-100">{props.rollnumber}</span>
                  </div>
                </div>
              </div>
            </header>
          </div>
          {/* Bio */}
          <div className="flex justify-start items-center gap-4 mt-2">
            <p className="text-lg font-semibold text-slate-100">Location</p>
            <div className="text-sm text-slate-100">{props.location}</div>
          </div>
          <div className="flex justify-start items-center gap-4">
            <p className="text-lg font-semibold text-slate-100">Country</p>
            <div className="text-sm text-slate-100">{props.country}</div>
          </div>
        </div>
        {/* Card footer */}
        <div className="border-t border-slate-200 dark:border-slate-700 ">
          <div className="flex divide-x divide-slate-200 dark:divide-slate-700">
            <div className="flex items-center justify-center text-lg font-medium w-full" >

            <div
              className="bg-primarycl text-white px-3 py-2 my-2 rounded-md mt-3"
              onClick={() => navigate("/viewprofile", { state: props.items })}
            >
              View Profile
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UsersTilesCard;
