import "./App.css";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Homepage from "./components/homepage/Homepage";
import Footer from "./components/footer/Footer";
import Navbar from "./components/header/Navbar";
import AddStudent from "./components/homepage/AddStudent";
import ViewProfile from "./components/homepage/ViewProfile";
function App() {
  return (
    <div className="App text-[#555]">

      <Navbar />
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/addstudent" element={<AddStudent />} />
        <Route path="/viewprofile" element={<ViewProfile />} />
      </Routes>
      <Footer />

    </div>
  );
}

export default App;